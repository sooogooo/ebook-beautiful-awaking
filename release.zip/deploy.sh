#!/bin/bash

# 🚀 美的觉醒 - 快速部署脚本
# 使用方法：./deploy.sh

echo "📚 美的觉醒 - 静态网站部署脚本"
echo "=================================="

# 检查是否在正确目录
if [ ! -f "index.html" ]; then
    echo "❌ 错误：请确保在包含 index.html 的目录中运行此脚本"
    exit 1
fi

# 检查 Python 是否可用
if command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
elif command -v python &> /dev/null; then
    PYTHON_CMD="python"
else
    echo "❌ 错误：未找到 Python，请安装 Python 2.7+ 或 3.x"
    exit 1
fi

echo "✅ 找到 Python: $PYTHON_CMD"

# 获取端口号
read -p "🌐 请输入端口号 (默认 8000): " PORT
PORT=${PORT:-8000}

echo "🚀 启动本地服务器..."
echo "📱 访问地址: http://localhost:$PORT"
echo "⏹️  按 Ctrl+C 停止服务器"
echo ""

# 启动服务器
$PYTHON_CMD -m http.server $PORT