# 📚 美的觉醒 - 静态网站部署说明

## 🚀 快速部署指南

### 方法一：直接部署（推荐）
1. **解压文件**：将 `release.zip` 解压到您的 Web 服务器目录
2. **访问网站**：通过浏览器访问 `index.html` 即可

### 方法二：本地预览
1. **解压文件**：`unzip release.zip`
2. **启动本地服务器**：
   ```bash
   # 使用 Python 3
   python3 -m http.server 8000
   
   # 或使用 Python 2
   python2 -m http.server 8000
   
   # 或使用 Node.js
   npx http-server
   ```
3. **访问预览**：打开浏览器访问 `http://localhost:8000`

## 📁 文件结构说明

```
release/
├── index.html                    # 网站首页
├── 404.html                     # 404错误页面
├── sitemap.xml                  # 站点地图
├── assets/                      # 静态资源
│   ├── images/                  # 图片资源
│   ├── javascripts/             # JavaScript 文件
│   └── stylesheets/            # CSS 样式文件
├── images/                      # 网站图片
│   ├── favicon.png             # 网站图标
│   ├── logo.png                # 网站标志
│   └── visuals/                # 可视化图表
├── javascripts/                 # 额外 JavaScript
├── stylesheets/                # 额外 CSS
├── search/                     # 搜索功能文件
└── part1-4/                    # 各章节内容
    ├── chapter1-13/
    │   └── index.html
```

## 🌐 部署到不同平台

### GitHub Pages
1. 将解压后的所有文件上传到 GitHub 仓库的 `gh-pages` 分支
2. 或上传到 `main` 分支的 `docs` 文件夹
3. 在仓库设置中启用 GitHub Pages

### Netlify
1. 将解压后的文件拖拽到 Netlify 部署界面
2. 或连接到 Git 仓库并设置发布目录为 `release`

### Vercel
1. 将解压后的文件上传到您的项目
2. 部署时选择静态网站模式

### Nginx/Apache
1. 将文件复制到 Web 服务器根目录（如 `/var/www/html/`）
2. 确保服务器有正确的文件权限

## 🎯 网站特性

### ✨ 核心功能
- 📱 **响应式设计** - 支持桌面和移动设备
- 🎨 **Material 主题** - 现代化的界面设计
- 🌓 **深色模式** - 自动切换支持
- 🔍 **全文搜索** - 内置搜索引擎
- 🧭 **导航系统** - 完整的标签和侧边栏导航
- 📖 **内容完整** - 包含所有 13 章内容

### 📚 内容结构
- **第一部分**：美的心理学（第1-3章）
- **第二部分**：理性之美（第4-6章）
- **第三部分**：实践智慧（第7-10章）
- **第四部分**：美的升华（第11-13章）

## 🔧 技术规格

- **框架**: MkDocs + Material 主题
- **字符编码**: UTF-8
- **总字数**: 111,500 中文字符
- **文件数量**: 14 个 HTML 文件
- **兼容性**: 现代浏览器（Chrome, Firefox, Safari, Edge）

## 📝 注意事项

1. **文件路径**: 保持相对路径不变，确保资源文件能正确加载
2. **字符编码**: 确保服务器使用 UTF-8 编码
3. **搜索功能**: 需要在 Web 服务器环境下运行，本地文件打开时搜索功能不可用
4. **浏览器兼容**: 建议使用现代浏览器以获得最佳体验

## 🤝 技术支持

如有部署问题，请联系：
- 邮箱：yuxiaodong@beaucare.org
- 作者：美的觉醒团队

---

**📖 美的觉醒 - 积极心理学视角下的现代女性与专业咨询师成长指南**